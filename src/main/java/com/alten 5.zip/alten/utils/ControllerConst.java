package com.alten.utils;

public class ControllerConst {

    public static final String ACCESS_DENIED = "Access Denied : Admin only";
    public static final String PRODUCT_NOT_FOUND = "Product not found";
    public static final String PRODUCT_DELETED_SUCCESSFULLY = "Product deleted successfully";
    public static final String ADMIN = "admin@admin.com";
}
